library(testthat)
library(tuneRanger)

test_check("tuneRanger")
